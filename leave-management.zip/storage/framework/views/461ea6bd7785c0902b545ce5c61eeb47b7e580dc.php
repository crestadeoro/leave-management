<?php $__env->startSection('title', 'Add Employee'); ?>

<?php $__env->startSection('extended css'); ?>
<style type="text/css">
    input {
        text-transform: uppercase;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Employee</h1>
</div>

<div class="row">
    <!-- Add Employee -->
    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
        <div class="card shadow mb-4">
            <!-- Card Header -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-warning">Add Employee</h6>
                <div class="dropdown no-arrow">
                </div>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="form-area">
                    <form method="POST" action="/employee/save-employee">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="form-group col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                <label for="employee_id">Employee Id</label>
                                <input type="text" class="form-control <?php if ($errors->has('employee_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('employee_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    id="employee_id" name="employee_id" value="<?php echo e(old('employee_id')); ?>" autofocus>
    
                                <?php if ($errors->has('employee_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('employee_id'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                <label for="firstname">Firstname</label>
                                <input type="text" class="form-control <?php if ($errors->has('firstname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('firstname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    id="firstname" name="firstname" value="<?php echo e(old('firstname')); ?>">
    
                                <?php if ($errors->has('firstname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('firstname'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="form-group col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                <label for="middlename">Middlename</label>
                                <input type="text" class="form-control <?php if ($errors->has('middlename')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('middlename'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    id="middlename" name="middlename" value="<?php echo e(old('middlename')); ?>">
    
                                <?php if ($errors->has('middlename')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('middlename'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="form-group col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                <label for="lastname">Lastname</label>
                                <input type="text" class="form-control <?php if ($errors->has('lastname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lastname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    id="lastname" name="lastname" value="<?php echo e(old('lastname')); ?>">
    
                                <?php if ($errors->has('lastname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lastname'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>                                                                                    
                        </div>
                        <div class="row">
                            <div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                <label for="birthday">Birthday</label>
                                <input type="date" class="form-control <?php if ($errors->has('birthday')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('birthday'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    id="birthday" name="birthday" value="<?php echo e(old('birthday')); ?>">
    
                                <?php if ($errors->has('birthday')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('birthday'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                <label for="date_hired">Date Hired</label>
                                <input type="date" class="form-control <?php if ($errors->has('date_hired')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date_hired'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    id="date_hired" name="date_hired" value="<?php echo e(old('date_hired')); ?>">
    
                                <?php if ($errors->has('date_hired')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date_hired'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>                                                                                    
                        </div>
                        <div class="row">
                            <div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                <label for="division">Division/Project</label>
                                <select class="form-control <?php if ($errors->has('division')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('division'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="division"
                                name="division">
                                    <option value="">SELECT</option>
                                    <?php $__currentLoopData = $Division; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Divisions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($Divisions->id); ?>" <?php if(old('division')==$Divisions->id): ?> selected
                                            <?php endif; ?>><?php echo e(strtoupper($Divisions->division)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
    
                                <?php if ($errors->has('division')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('division'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                <label for="position">Position</label>
                                <select class="form-control <?php if ($errors->has('position')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('position'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="position"
                                name="position">
                                    <option value="">SELECT</option>
                                    <?php $__currentLoopData = $Position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Positions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($Positions->id); ?>" <?php if(old('position')==$Positions->id): ?> selected
                                            <?php endif; ?>><?php echo e(strtoupper($Positions->position)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
    
                                <?php if ($errors->has('position')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('position'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>                                                                                   
                        </div>
                        <div class="row">
                            <div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <label for="status">Status</label>
                                <select class="form-control <?php if ($errors->has('status')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('status'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="status"
                                name="status">
                                    <option value="">SELECT</option>
                                    <option value="contractual" <?php if(old('status') == 'contractual'): ?> selected <?php endif; ?>>CONTRACTUAL</option>
                                    <option value="probitionary" <?php if(old('status') == 'probitionary'): ?> selected <?php endif; ?>>PROBITIONARY</option>
                                    <option value="regular" <?php if(old('status') == 'regular'): ?> selected <?php endif; ?>>REGULAR</option>
                                    <option value="resigned" <?php if(old('status') == 'resigned'): ?> selected <?php endif; ?>>RESIGNED</option>
                                    <option value="terminated" <?php if(old('status') == 'terminated'): ?> selected <?php endif; ?>>TERMINATED</option>
                                </select>
    
                                <?php if ($errors->has('status')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('status'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>                                                                                   
                        </div>                                                                        
                        <button type="submit" class="btn btn-success">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(session('success')): ?>
<div class="toast" role="alert" aria-live="polite" aria-atomic="true" data-delay="3000"
    style="position: absolute; top: 75px; right: 0; width: 250px">
    <div class="toast-header">
        <strong class="mr-auto">GoldridgeCDC</strong>
        <small>Now</small>
        <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="toast-body">
        <?php echo e(session('success')); ?>

    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extended js'); ?>
<script type="text/javascript">
    $('.toast').toast('show')

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goldridge\leave-management\resources\views/employee/add-employee.blade.php ENDPATH**/ ?>