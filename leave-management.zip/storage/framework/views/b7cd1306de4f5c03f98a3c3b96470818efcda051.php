<?php $__env->startSection('title', 'Position'); ?>

<?php $__env->startSection('extended css'); ?>
<style type="text/css">
    input {
        text-transform: uppercase;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Position</h1>
    </div>

    <div class="row">
        <!-- View Position -->
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
        	<div class="card shadow mb-4">
            	<!-- Card Header -->
            	<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
              		<h6 class="m-0 font-weight-bold text-warning">View Position</h6>
              		<div class="dropdown no-arrow">
              		</div>
            	</div>
            	<!-- Card Body -->
            	<div class="card-body">

            	</div>
          	</div>
        </div>
        
        <!-- Add Position -->
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
        	<div class="card shadow mb-4">
            	<!-- Card Header -->
            	<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
              		<h6 class="m-0 font-weight-bold text-warning">Add Position</h6>
              		<div class="dropdown no-arrow">
              		</div>
            	</div>
            	<!-- Card Body -->
            	<div class="card-body">
            		<div class="form-area">
                		<form method="POST" action="/employee/save-position">
                			<?php echo e(csrf_field()); ?>

                			<div class="form-group">
    							<label for="position">Position Name</label>
    							<input type="text" class="form-control <?php if ($errors->has('position')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('position'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="position" name="position" autofocus>

    							<?php if ($errors->has('position')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('position'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
  							</div>
  							<button type="submit" class="btn btn-success">Submit</button>
                		</form>
              		</div>
            	</div>
          	</div>
        </div>        
    </div>

<?php if(session('success')): ?>
<div class="toast" role="alert" aria-live="polite" aria-atomic="true" data-delay="3000"
    style="position: absolute; top: 75px; right: 0; width: 250px">
    <div class="toast-header">
        <strong class="mr-auto">GoldridgeCDC</strong>
        <small>Now</small>
        <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="toast-body">
        <?php echo e(session('success')); ?>

    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extended js'); ?>
<script type="text/javascript">
    $('.toast').toast('show')

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goldridge\leave-management\resources\views/employee/position.blade.php ENDPATH**/ ?>