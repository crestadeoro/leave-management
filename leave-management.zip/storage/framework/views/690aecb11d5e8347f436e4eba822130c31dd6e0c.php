<?php $__env->startSection('title', 'Employee List'); ?>

<?php $__env->startSection('extended css'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('admin-template/vendor/datatables/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Employee</h1>
    </div>

    <div class="row">
        <div class="col-xl-12 col-lg-12">
        	<div class="card shadow mb-4">
            	<!-- Card Header -->
            	<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
              		<h6 class="m-0 font-weight-bold text-primary">Employee List</h6>
              		<div class="dropdown no-arrow">
              		</div>
            	</div>
            	<!-- Card Body -->
            	<div class="card-body">
            		<div class="table-responsive">
            			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            				<thead>
            					<tr>
									<th>Employee ID</th>
									<th>Name</th>
									<th>Birthday</th>
                                    <th>Date Hired</th>
                                    <th>Division/Project</th>
									<th>Position</th>
									<th>Status</th>
									<th>Action</th>
            					</tr>
            				</thead>
            				<tbody>
                                <?php $__currentLoopData = $EmployeeDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $EmployeeDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($EmployeeDetails->employee_id); ?></td>
										<td><?php echo e(strtoupper($EmployeeDetails->lastname).', '.strtoupper($EmployeeDetails->firstname).' '.strtoupper($EmployeeDetails->middlename)); ?></td>
										<td><?php echo e(date('F d, Y', strtotime($EmployeeDetails->birthday))); ?></td>
										<td><?php echo e(date('F d, Y', strtotime($EmployeeDetails->date_hired))); ?></td>
                                        <td><?php echo e(strtoupper($EmployeeDetails->division)); ?></td>
										<td><?php echo e(strtoupper($EmployeeDetails->position)); ?></td>
										<td><?php echo e(strtoupper($EmployeeDetails->status)); ?></td>
										<td><a href="/employee/view-employee/<?php echo e($EmployeeDetails->id); ?>" class="btn btn-success btn-sm btn-circle"><i class="fas fa-eye"></i></i></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            				</tbody>
            			</table>
            		</div>
            	</div>
          	</div>
        </div>    	
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extended js'); ?>
	<!-- Page level plugins -->
  	<script src="<?php echo e(asset('admin-template/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
  	<script src="<?php echo e(asset('admin-template/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

  	<!-- Page level custom scripts -->
  	<script src="<?php echo e(asset('admin-template/js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goldridge\leave-management\resources\views/employee/list-employee.blade.php ENDPATH**/ ?>