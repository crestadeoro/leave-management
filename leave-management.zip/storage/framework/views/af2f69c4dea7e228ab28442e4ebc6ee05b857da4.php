<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <title>Leave Management System</title>

  	<!-- Custom styles for this template-->
  	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin-template/vendor/fontawesome-free/css/all.min.css')); ?>">
  	<link rel="stylesheet" href="<?php echo e(asset('admin-template/css/sb-admin-2.min.css')); ?>">

    <!-- welcome css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">

    <!-- Google Font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito">
</head>
<body>

    <div class="container">
        <div class="row justify-content-md-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <center><h3>Sign In</h3>
                                        <h5>Leave Management System</h5>
                                </center>
                            </div>
                        </div>
                        <br>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                             <?php echo csrf_field(); ?>
                             <div class="form-group row">
                                 <label for="email" class="col-md-1 col-form-label"><i class="fas fa-user fa-lg"></i></label>

                                 <div class="col-md-11">
                                     <input id="username" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username"  autofocus>

                                     <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                                         <span class="invalid-feedback" role="alert">
                                             <strong><?php echo e($message); ?></strong>
                                         </span>
                                     <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                 </div>
                             </div>
                            <div class="form-group row">
                                <label for="password" class="col-md-1 col-form-label"><i class="fas fa-key fa-lg"></i></label>

                                <div class="col-md-11">
                                    <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" placeholder="Password"  autocomplete="current-password">

                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success col-12 login-btn">Proceed</button>
                         </form>
                    </div>
                </div> 
            </div>
        </div>
    </div>

    <!-- jQuery, AJAX, BScdn -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\goldridge\leave-management\resources\views/auth/login.blade.php ENDPATH**/ ?>